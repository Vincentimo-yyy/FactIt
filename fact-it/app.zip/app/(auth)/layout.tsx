import type React from 'react';
import type { Metadata } from 'next';
import '../globals.css';

export const metadata: Metadata = {
  title: 'Authentication - Factit',
  description: 'Sign in or sign up to Factit',
};

export default function AuthLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="font-arial antialiased bg-gray-50">{children}</body>
    </html>
  );
}
